from .views import index, new_client, client_detail
