from .views import (
    index,
    final,
    setup_done,
    account_activated,
    extension_redirect,
)
