require.config({
    shim: {
        'input-mask': ['jquery', 'core']
    },
    paths: {
        'input-mask': 'assets/plugins/input-mask/js/jquery.mask.min'
    }
});